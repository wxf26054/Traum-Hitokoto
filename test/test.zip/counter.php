<?php

require_once './src/IpLocation.php';
use itbdw\Ip\IpLocation;

//设置时区
date_default_timezone_set("PRC");

function counter() {
    $numUrl = "./count_data/counter.dat";
    $ipUrl = "./count_data/ip.dat";
    $ip_last_view = "./count_data/ip_last_view.dat";
    $everydayUrl = "./count_data/everyday.dat";

    $nowIp = $_SERVER['REMOTE_ADDR'];
    $nowTime = $_SERVER['REQUEST_TIME'];
    $counter = explode(';',file_get_contents($numUrl));

    //计算总访问量
    $counter[0] = (int)$counter[0];

    $ip_log = explode(';',file_get_contents($ipUrl));
    $ip_last_view_log = explode(';',file_get_contents($ip_last_view));
    $everyDay = explode(';',file_get_contents($everydayUrl));

    $if_view_brfore = 0;
    $add = 0;

    //临时变量 $length
    $length = empty($ip_log[0]) ? 0:count($ip_log);
    $ip_last_view_log_length = empty($ip_last_view_log[0]) ? 0:count($ip_last_view_log);

    $hour_now = date("H",$nowTime);

    $if_ip_last_view_log = false;
    for ($i = 0 ; $i < $ip_last_view_log_length ;$i += 2) {
        if ($ip_last_view_log[$i+1] < strtotime(date('Y-m-d', time()))) {
            unset($ip_last_view_log[$i]);
            unset($ip_last_view_log[$i+1]);
        }
        if ($ip_last_view_log[$i] == $nowIp) {
            $if_ip_last_view_log = true;
            $ip_last_view_log[$i+1] = $nowTime;
        }
    }
    //这个ip第一次出现
    if (!$if_ip_last_view_log) {
        $ip_last_view_log[$i] = $nowIp;
        $ip_last_view_log[$i+1] = $nowTime;
    }

    for ($i = 0 ; $i < $length ;$i += 2) {
        if ($ip_log[$i] == $nowIp) {

            //这个ip出现过
            $if_view_brfore = 1;

        }
    }

    //这个ip第一次出现
    if ($if_view_brfore == 0) {
        $ip_log[$i] = $nowIp;
        $ip_log[$i+1] = $nowTime;
        $counter[0]++;
    }

    //改变临时变量
    $length = empty($everyDay[0]) ? 0:count($everyDay);

    $today = date("Y-m-d", $nowTime);
    $first = 1;

    //今日第一个访问
    $todayLog = 0 ;

    if ($add || $if_view_brfore == 0) {
        for ($i = 0; $i < $length;$i += 2) {
            if ($everyDay[$i] == $today) {
                $everyDay[$i+1] = (int)$everyDay[$i+1];
                $everyDay[$i+1]++;
                $todayNum = $everyDay[$i+1];
                $first = 0;
            }
        }
        if ($first) {
            $everyDay[$i] = $today;
            $everyDay[$i+1] = 1;
            $todayNum = 1;
        }

    } else {
        for ($i = 0; $i < $length;$i += 2) {
            if ($everyDay[$i] == $today) {
                $todayLog = 1;
                $todayNum = $everyDay[$i+1];
            }
        }
        if ($todayLog == 0) {
            $todayNum = 1;
        }
    }
    $totalNum = $counter[0];
    file_put_contents($numUrl, implode(";", $counter));
    file_put_contents($ipUrl, implode(";", $ip_log));
    file_put_contents($ip_last_view, implode(";", $ip_last_view_log));
    file_put_contents($everydayUrl, implode(";", $everyDay));
    $result = array('all' => $totalNum, 'today' => (int)$todayNum);
    return $result;
}

function showEveryday() {
    $everydayUrl = "./count_data/everyday.dat";
    $everyDay = explode(';',file_get_contents($everydayUrl));
    $length = empty($everyDay[0]) ? 0:count($everyDay);
    for ($i = 0;$i < $length;$i += 2) {
        echo $everyDay[$i].":";
        echo $everyDay[$i+1]."<br/>";
    }
}

//显示当天访问IP
function showTodayIp() {
    $ToDayUrl = "./count_data/ip_last_view.dat";
    $ToDay = explode(';',file_get_contents($ToDayUrl));
    $length = empty($ToDay[0]) ? 0:count($ToDay);
    //echo '<tr><td>IP</td><td>地址</td><td>最后来访时间</td></tr>';
    $num = 0;
    for ($i = 0;$i < $length;$i += 2) {
        $info_array = IpLocation::getLocation($ToDay[$i]);
        $info[$num]['ip'] = preg_replace('/(\d+)\.(\d+)\.(\d+)\.(\d+)/is',"$1.$2.$3.*",$info_array['ip']);
        $info[$num]['position'] = (!empty($info_array['country'])?$info_array['country'].' ':'').(!empty($info_array['province'])?$info_array['province'].' ':'').(!empty($info_array['city'])?$info_array['city'].' ':'').(!empty($info_array['county'])?$info_array['county'].' ':'').(!empty($info_array['isp'])?$info_array['isp'].' ':'').(!empty($info_array['area'])?$info_array['area']:'');
        $info[$num]['last_visit'] = date('H:i:s',$ToDay[$i+1]);
        $num++;
    }
    
    $exchange = array();
    for ($y = 0; $y < count($info)-1; $y++) {
        for ($x = 0; $x < count($info)-$y-1; $x++) {
            //echo $x;
            if ($info[$x]['last_visit'] < $info[$x+1]['last_visit']) {
                //echo $info[$x]['last_visit'] .'-'. $info[$x+1]['last_visit'].'||||';
                $exchange = $info[$x];
                $info[$x] = $info[$x+1];
                $info[$x+1] = $exchange;
            }
        }
    }
    return $info;
}

function online() {
    $online_log = "./count_data/online_now.dat";
    $online_highest = "./count_data/online_highest.dat";
    
    $timeout = 30;
    $entries = file($online_log);
    
    $online_highest_entry = file_get_contents($online_highest);
    $temp = array();
    for ($i = 0;$i < count($entries);$i++) {
        $entry = explode(",",trim($entries[$i]));
        if (($entry[0] != getenv('REMOTE_ADDR')) && ($entry[1] > time())) {
            array_push($temp,$entry[0].",".$entry[1]."\n");
        }
    }
    array_push($temp,getenv('REMOTE_ADDR').",".(time() + ($timeout))."\n");
    $online = count($temp);
    if($online_highest_entry < $online)
        $online_highest_entry = $online;
    $entries = implode("",$temp);
    $fp = fopen($online_log,"w");
    flock($fp,LOCK_EX);
    fputs($fp,$entries);
    flock($fp,LOCK_UN);
    fclose($fp);
    
    $fp = fopen($online_highest,"w");
    flock($fp,LOCK_EX);
    fputs($fp,$online_highest_entry);
    flock($fp,LOCK_UN);
    fclose($fp);
    
    //处理在线访客信息
    $online_visitors = file($online_log);
    $visitor_num = empty($online_visitors[0]) ? 0:count($online_visitors);
    for ($i = 0;$i < $visitor_num;$i++) {
        
        $visitor = explode(',',$online_visitors[$i]);
        
        $info_array = IpLocation::getLocation($visitor[0]);
        
        $visitor_info[$i]['ip'] = preg_replace('/(\d+)\.(\d+)\.(\d+)\.(\d+)/is',"$1.$2.$3.*",$info_array['ip']);
        $visitor_info[$i]['position'] = (!empty($info_array['country'])?$info_array['country'].' ':'').(!empty($info_array['province'])?$info_array['province'].' ':'').(!empty($info_array['city'])?$info_array['city'].' ':'').(!empty($info_array['county'])?$info_array['county'].' ':'').(!empty($info_array['isp'])?$info_array['isp'].' ':'').(!empty($info_array['area'])?$info_array['area']:'');
        $visitor_info[$i]['last_visit'] = date('H:i:s',$visitor[1]);
        
    }
    
    $exchange = array();
    for ($y = 0; $y < count($visitor_info)-1; $y++) {
        for ($x = 0; $x < count($visitor_info)-$y-1; $x++) {
            //echo $x;
            if ($visitor_info[$x]['last_visit'] < $visitor_info[$x+1]['last_visit']) {
                //echo $info[$x]['last_visit'] .'-'. $info[$x+1]['last_visit'].'||||';
                $exchange = $visitor_info[$x];
                $visitor_info[$x] = $visitor_info[$x+1];
                $visitor_info[$x+1] = $exchange;
            }
        }
    }
    //End
    
    $array = array(
            'now' => $online,
            'highest' => $online_highest_entry,
            'visitor' => $visitor_info
        );
    return $array;
}