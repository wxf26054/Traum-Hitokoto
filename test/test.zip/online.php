<?php

require_once 'counter.php';

header('Cache-Control:no-cache,must-revalidate');
header('Pragma:no-cache');
header("Expires:0");
$online_log = "./count_data/online_now.dat";
$timeout = 30;
$entries = file($online_log);
$temp = array();
for ($i = 0;$i < count($entries);$i++) {
    $entry = explode(",",trim($entries[$i]));
    if (($entry[0] != getenv('REMOTE_ADDR')) && ($entry[1] > time())) {
        array_push($temp,$entry[0].",".$entry[1]."\n");
    }}
array_push($temp,getenv('REMOTE_ADDR').",".(time() + ($timeout))."\n");
$maplers = count($temp);
$entries = implode("",$temp);
$fp = fopen($online_log,"w");
flock($fp,LOCK_EX);
fputs($fp,$entries);
flock($fp,LOCK_UN);
fclose($fp);
counter();
echo $maplers;