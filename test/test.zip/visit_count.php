<?php

header('Cache-Control:no-cache,must-revalidate');
header('Pragma:no-cache');
header("Expires:0");
header('content-type: application/json');

require_once 'counter.php';

$array = array();
$array['visit_count'] = counter();
$array['visitors']    = showTodayIp();
$array['online']      = online();
$array['ip']          = $_SERVER['REMOTE_ADDR'];
$array['datebase_last_update'] = file_get_contents('bin/update_log.dat');

echo json_encode($array,true);