<html>
    
    <head>
        <title>统计</title>
        <link rel="stylesheet" href="/css/github-markdown.css">
        <style>
        blockquote {
            margin: 1em 1.5em;
            padding-left: 1.5em;
            border-left: 4px solid #F3F3F0;
            border-right: 4px solid #F3F3F0;
            background: rgba(255, 255, 255, 0.3);
        }
        </style>
    </head>
    
    <body>
        
        <div class="markdown-body">
            <div id="hitotimes"></div>
            当前在线：<span id="online"></span>
        </div>
        <script crossorigin="anonymous" integrity="sha384-lifoBlbdwizTl3Yoe612uhI3AcOam/QtWkozF7SuiACaf5UJl5reOYu4MigVxrCH" src="https://lib.baomitu.com/jquery/1.8.3/jquery.min.js"></script>
        <script>
        function update() {
    $.getJSON("/visit_count.php", function (res) {
        
        document.getElementById("online").innerHTML = res.online.now;
        
        var apistyle, apionlinevisitor, apiip, apitime, apilist, apionline;

        apilist = `<b>当前在线人数：${res.online.now}   历史最高在线人数：${res.online.highest}</b><br /><br />`;
        
        apilist += '<table border="0" style="width:100%;text-align: center;"><tr><td>IP</td><td>地址</td></tr>';
        apionlinevisitor = Object.keys(res.online.visitor).sort(function (a, b) {
            return res.visit_count[b] - res.visit_count[a]
        });
        Object.keys(apionlinevisitor).forEach(function (key) {
            apistyle = key % 2 === 0 ? ' style="background:rgba(255,255,255,0.3);"' : '';
            apilist += ` <tr${apistyle}><td> ${res.online.visitor[apionlinevisitor[key]].ip}</td><td>${res.online.visitor[apionlinevisitor[key]].position}</td></tr>`;
        });
        apilist += '</table>';
        
        apilist += '<table border="0" style="width:100%;text-align: center;"><tr><td>访问时间</td><td>次数</td></tr>';
        apitime = Object.keys(res.visit_count).sort(function (a, b) {
            return res.visit_count[b] - res.visit_count[a]
        });
        Object.keys(apitime).forEach(function (key) {
            apistyle = key % 2 === 0 ? ' style="background:rgba(255,255,255,0.3);"' : '';
            apilist += ` <tr${apistyle}><td> ${apitime[key]}</td><td>${res.visit_count[apitime[key]]} r</td></tr>`;
        });
        apilist += '</table>';

        apilist += '<table border="0" style="width:100%;text-align: center;"><tr><td>IP</td><td>地址</td><td>最后停留时间</td></tr>';
        apiip = Object.keys(res.visitors);
        
        Object.keys(apiip).forEach(function (key) {
            apistyle = key % 2 === 0 ? ' style="background:rgba(255,255,255,0.3);"' : '';
            apilist += `<tr${apistyle}><td> ${res.visitors[apiip[key]].ip}</td><td> ${res.visitors[apiip[key]].position}</td><td>${res.visitors[apiip[key]].last_visit}</td></tr>`;
        });
        apilist += '</table><br />';
        
        apilist += `<b>数据库：纯真网络 ${res.datebase_last_update}数据</b><br />`;
        
        $('#hitotimes').html(apilist);
    });
}
update();
setInterval(update, 5000);
        </script>
    </body>

</html>